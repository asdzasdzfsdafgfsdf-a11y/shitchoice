package com.choicemod;

import com.choicemod.common.event.ChoiceScheduler;
import com.choicemod.common.packet.ChoicePackets;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ChoiceMod implements ModInitializer {

    public static final String MOD_ID = "choicemod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    // Интервал между выборами в секундах (можно менять)
    public static final int CHOICE_INTERVAL_SECONDS = 120;

    @Override
    public void onInitialize() {
        LOGGER.info("[ChoiceMod] Загружаем мод выборов...");
        ChoicePackets.registerServerPackets();
        ServerTickEvents.END_SERVER_TICK.register(new ChoiceScheduler());
        LOGGER.info("[ChoiceMod] Мод загружен! Выборы каждые {} сек.", CHOICE_INTERVAL_SECONDS);
    }
}
