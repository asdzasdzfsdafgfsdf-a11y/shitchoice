package com.choicemod.common.registry;

import net.minecraft.server.network.ServerPlayerEntity;

/**
 * Один пакет выбора: название, описание бонуса, описание штрафа,
 * и лямбды для применения/снятия эффектов.
 */
public class ChoiceEntry {

    public final String id;
    public final String title;
    public final String bonusDesc;
    public final String penaltyDesc;

    private final ChoiceEffect applyEffect;
    private final ChoiceEffect removeEffect;

    public ChoiceEntry(String id, String title, String bonusDesc, String penaltyDesc,
                       ChoiceEffect applyEffect, ChoiceEffect removeEffect) {
        this.id = id;
        this.title = title;
        this.bonusDesc = bonusDesc;
        this.penaltyDesc = penaltyDesc;
        this.applyEffect = applyEffect;
        this.removeEffect = removeEffect;
    }

    public void apply(ServerPlayerEntity player) {
        applyEffect.execute(player);
    }

    public void remove(ServerPlayerEntity player) {
        removeEffect.execute(player);
    }

    @FunctionalInterface
    public interface ChoiceEffect {
        void execute(ServerPlayerEntity player);
    }
}
