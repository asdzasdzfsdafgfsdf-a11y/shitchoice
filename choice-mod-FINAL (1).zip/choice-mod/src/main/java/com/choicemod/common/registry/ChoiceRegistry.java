package com.choicemod.common.registry;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.*;

/**
 * Реестр всех доступных пакетов выборов.
 * Добавляй сюда новые — просто докинь в список ENTRIES.
 */
public class ChoiceRegistry {

    // UUID для атрибутов (уникальные, чтобы не конфликтовали)
    private static final UUID SPEED_UUID    = UUID.fromString("a1b2c3d4-0001-0000-0000-000000000001");
    private static final UUID STRENGTH_UUID = UUID.fromString("a1b2c3d4-0002-0000-0000-000000000002");
    private static final UUID HEALTH_UUID   = UUID.fromString("a1b2c3d4-0003-0000-0000-000000000003");
    private static final UUID REACH_UUID    = UUID.fromString("a1b2c3d4-0004-0000-0000-000000000004");

    private static final Random RANDOM = new Random();

    public static final List<ChoiceEntry> ENTRIES = new ArrayList<>();

    static {

        // ══════════════════════════════════════════════════════════════════
        //  ПАКЕТ 1: Скорость III + Голод постоянный
        // ══════════════════════════════════════════════════════════════════
        ENTRIES.add(new ChoiceEntry(
                "speed_hunger",
                "§b⚡ Молния в ногах",
                "§aСкорость III — летаешь как пуля",
                "§cПостоянный голод — жрёшь как лошадь",
                player -> {
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, Integer.MAX_VALUE, 2, false, true, true));
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.HUNGER, Integer.MAX_VALUE, 1, false, true, true));
                    notify(player, "§b⚡ Скорость III активна! §cНо теперь всегда голоден.");
                },
                player -> {
                    player.removeStatusEffect(StatusEffects.SPEED);
                    player.removeStatusEffect(StatusEffects.HUNGER);
                }
        ));

        // ══════════════════════════════════════════════════════════════════
        //  ПАКЕТ 2: Сила II + Слабость зрения (темнота)
        // ══════════════════════════════════════════════════════════════════
        ENTRIES.add(new ChoiceEntry(
                "strength_blindness",
                "§4💪 Слепой берсерк",
                "§aСила II — каждый удар как кувалда",
                "§cПостоянная темнота — видишь на 2 блока",
                player -> {
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, Integer.MAX_VALUE, 1, false, true, true));
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, Integer.MAX_VALUE, 0, false, true, true));
                    notify(player, "§4💪 Сила II! §cНо мир во тьме...");
                },
                player -> {
                    player.removeStatusEffect(StatusEffects.STRENGTH);
                    player.removeStatusEffect(StatusEffects.DARKNESS);
                }
        ));

        // ══════════════════════════════════════════════════════════════════
        //  ПАКЕТ 3: Зачарование случайных вещей + блоки под ногами исчезают
        // ══════════════════════════════════════════════════════════════════
        ENTRIES.add(new ChoiceEntry(
                "enchant_void",
                "§d✨ Магическая земля",
                "§aВсе вещи в инвентаре зачарованы рандомом",
                "§cБлоки под ногами исчезают каждые 10 сек",
                player -> {
                    enchantInventory(player);
                    // Помечаем тег — тикер сервера будет убирать блоки
                    player.getDataTracker(); // просто инициализация
                    player.addCommandTag("choice_void_floor");
                    notify(player, "§d✨ Вещи зачарованы! §cНо земля уходит из-под ног...");
                },
                player -> {
                    player.removeCommandTag("choice_void_floor");
                    notify(player, "§7Эффект «Магическая земля» снят.");
                }
        ));

        // ══════════════════════════════════════════════════════════════════
        //  ПАКЕТ 4: Регенерация II + Эффект яда навсегда
        // ══════════════════════════════════════════════════════════════════
        ENTRIES.add(new ChoiceEntry(
                "regen_poison",
                "§2☠ Живучий мертвец",
                "§aРегенерация II — хил почти мгновенный",
                "§cЯд навсегда — HP никогда не выше 50%",
                player -> {
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, Integer.MAX_VALUE, 1, false, true, true));
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, Integer.MAX_VALUE, 0, false, true, true));
                    notify(player, "§2☠ Регенерация II! §cНо яд будет есть тебя вечно.");
                },
                player -> {
                    player.removeStatusEffect(StatusEffects.REGENERATION);
                    player.removeStatusEffect(StatusEffects.POISON);
                }
        ));

        // ══════════════════════════════════════════════════════════════════
        //  ПАКЕТ 5: Прыжок V + Левитация (без контроля)
        // ══════════════════════════════════════════════════════════════════
        ENTRIES.add(new ChoiceEntry(
                "jump_levitate",
                "§e🌙 Лунный козёл",
                "§aПрыжок V — прыгаешь как на луне",
                "§cЛевитация — иногда улетаешь в небо",
                player -> {
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, Integer.MAX_VALUE, 4, false, true, true));
                    // Левитацию будем накладывать периодически через тег
                    player.addCommandTag("choice_random_levitate");
                    notify(player, "§e🌙 Прыжок V! §cНо иногда тебя уносит в небеса...");
                },
                player -> {
                    player.removeStatusEffect(StatusEffects.JUMP_BOOST);
                    player.removeStatusEffect(StatusEffects.LEVITATION);
                    player.removeCommandTag("choice_random_levitate");
                }
        ));

        // ══════════════════════════════════════════════════════════════════
        //  ПАКЕТ 6: Удача при добыче + Медлительность III
        // ══════════════════════════════════════════════════════════════════
        ENTRIES.add(new ChoiceEntry(
                "luck_slow",
                "§6🐌 Золотая черепаха",
                "§aУдача III — блоки дропают вдвойне",
                "§cМедлительность III — скорость как у деда",
                player -> {
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.LUCK, Integer.MAX_VALUE, 2, false, true, true));
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, Integer.MAX_VALUE, 2, false, true, true));
                    notify(player, "§6🐌 Удача III! §cНо теперь ты ходишь как черепаха.");
                },
                player -> {
                    player.removeStatusEffect(StatusEffects.LUCK);
                    player.removeStatusEffect(StatusEffects.SLOWNESS);
                }
        ));

        // ══════════════════════════════════════════════════════════════════
        //  ПАКЕТ 7: Невидимость + Слабость навсегда
        // ══════════════════════════════════════════════════════════════════
        ENTRIES.add(new ChoiceEntry(
                "invis_weak",
                "§7👻 Призрак-слабак",
                "§aНевидимость — мобы тебя не видят",
                "§cСлабость II — урон почти нулевой",
                player -> {
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.INVISIBILITY, Integer.MAX_VALUE, 0, false, true, true));
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, Integer.MAX_VALUE, 1, false, true, true));
                    notify(player, "§7👻 Невидимость! §cНо твои удары как поглаживание.");
                },
                player -> {
                    player.removeStatusEffect(StatusEffects.INVISIBILITY);
                    player.removeStatusEffect(StatusEffects.WEAKNESS);
                }
        ));

        // ══════════════════════════════════════════════════════════════════
        //  ПАКЕТ 8: Огнестойкость + Потеря HP каждые 5 сек
        // ══════════════════════════════════════════════════════════════════
        ENTRIES.add(new ChoiceEntry(
                "fire_bleed",
                "§c🔥 Горящая кровь",
                "§aОгнестойкость — огонь и лава не страшны",
                "§cКровотечение — теряешь 1 HP каждые 5 сек",
                player -> {
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, Integer.MAX_VALUE, 0, false, true, true));
                    player.addCommandTag("choice_bleed");
                    notify(player, "§c🔥 Огнестойкость! §cНо твоя кровь капает...");
                },
                player -> {
                    player.removeStatusEffect(StatusEffects.FIRE_RESISTANCE);
                    player.removeCommandTag("choice_bleed");
                }
        ));

        // ══════════════════════════════════════════════════════════════════
        //  ПАКЕТ 9: Ночное зрение + Случайный телепорт каждые 30 сек
        // ══════════════════════════════════════════════════════════════════
        ENTRIES.add(new ChoiceEntry(
                "nightvision_tp",
                "§9🌌 Блуждающий глаз",
                "§aНочное зрение — ночь как день",
                "§cТелепорт в случайную точку каждые 30 сек",
                player -> {
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, Integer.MAX_VALUE, 0, false, true, true));
                    player.addCommandTag("choice_random_tp");
                    notify(player, "§9🌌 Ночное зрение! §cНо тебя будет кидать по миру...");
                },
                player -> {
                    player.removeStatusEffect(StatusEffects.NIGHT_VISION);
                    player.removeCommandTag("choice_random_tp");
                }
        ));

        // ══════════════════════════════════════════════════════════════════
        //  ПАКЕТ 10: Водное дыхание + Медленное падение отключено (урон x2)
        // ══════════════════════════════════════════════════════════════════
        ENTRIES.add(new ChoiceEntry(
                "water_fall",
                "§3🌊 Рыба-самоубийца",
                "§aВодное дыхание + скорость в воде",
                "§cУрон от падения x2 навсегда",
                player -> {
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.WATER_BREATHING, Integer.MAX_VALUE, 0, false, true, true));
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.DOLPHINS_GRACE, Integer.MAX_VALUE, 0, false, true, true));
                    player.addCommandTag("choice_double_fall");
                    notify(player, "§3🌊 Рыба! §cНо каждое падение вдвойне больнее.");
                },
                player -> {
                    player.removeStatusEffect(StatusEffects.WATER_BREATHING);
                    player.removeStatusEffect(StatusEffects.DOLPHINS_GRACE);
                    player.removeCommandTag("choice_double_fall");
                }
        ));
    }

    /** Случайно берёт два разных пакета для показа игроку */
    public static ChoiceEntry[] getTwoCandidates() {
        List<ChoiceEntry> shuffled = new ArrayList<>(ENTRIES);
        Collections.shuffle(shuffled, RANDOM);
        return new ChoiceEntry[]{ shuffled.get(0), shuffled.get(1) };
    }

    /** Зачаровать рандомно все вещи в инвентаре */
    @SuppressWarnings("deprecation")
    private static void enchantInventory(ServerPlayerEntity player) {
        // Простой список чар которые точно есть в 1.21.1
        List<RegistryKey<Enchantment>> enchKeys = List.of(
                Enchantments.SHARPNESS, Enchantments.PROTECTION,
                Enchantments.EFFICIENCY, Enchantments.FORTUNE,
                Enchantments.LOOTING, Enchantments.FIRE_ASPECT,
                Enchantments.FEATHER_FALLING, Enchantments.INFINITY
        );

        var enchRegistry = player.getServerWorld().getRegistryManager().get(RegistryKeys.ENCHANTMENT);

        for (int i = 0; i < player.getInventory().size(); i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (stack.isEmpty()) continue;

            // Берём 1-2 случайных чары
            List<RegistryKey<Enchantment>> chosen = new ArrayList<>(enchKeys);
            Collections.shuffle(chosen, RANDOM);
            int count = 1 + RANDOM.nextInt(2);

            ItemEnchantmentsComponent.Builder builder = new ItemEnchantmentsComponent.Builder(
                    stack.getOrDefault(DataComponentTypes.ENCHANTMENTS, ItemEnchantmentsComponent.DEFAULT)
            );

            for (int c = 0; c < Math.min(count, chosen.size()); c++) {
                enchRegistry.getEntry(chosen.get(c)).ifPresent(entry -> {
                    int lvl = 1 + RANDOM.nextInt(3);
                    builder.add(entry, lvl);
                });
            }

            stack.set(DataComponentTypes.ENCHANTMENTS, builder.build());
        }
    }

    private static void notify(ServerPlayerEntity player, String msg) {
        player.sendMessage(Text.literal(msg), true); // true = actionbar
    }
}
