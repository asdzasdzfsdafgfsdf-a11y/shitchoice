package com.choicemod.common.event;

import com.choicemod.common.registry.ChoiceEntry;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Хранит для каждого игрока:
 * - Два pending пакета которые сейчас на экране выбора
 * - Текущий активный пакет (для снятия при следующем выборе)
 */
public class PlayerChoiceData {

    // pending[uuid] = {left, right}
    private static final Map<UUID, ChoiceEntry[]> PENDING = new HashMap<>();

    // active[uuid] = текущий активный пакет
    private static final Map<UUID, ChoiceEntry> ACTIVE = new HashMap<>();

    public static void setPending(ServerPlayerEntity player, ChoiceEntry left, ChoiceEntry right) {
        PENDING.put(player.getUuid(), new ChoiceEntry[]{ left, right });
    }

    public static ChoiceEntry[] getPending(ServerPlayerEntity player) {
        return PENDING.get(player.getUuid());
    }

    public static void clearPending(ServerPlayerEntity player) {
        PENDING.remove(player.getUuid());
    }

    public static ChoiceEntry getActive(ServerPlayerEntity player) {
        return ACTIVE.get(player.getUuid());
    }

    public static void setActive(ServerPlayerEntity player, ChoiceEntry entry) {
        ACTIVE.put(player.getUuid(), entry);
    }

    public static void clearAll(ServerPlayerEntity player) {
        PENDING.remove(player.getUuid());
        ACTIVE.remove(player.getUuid());
    }
}
