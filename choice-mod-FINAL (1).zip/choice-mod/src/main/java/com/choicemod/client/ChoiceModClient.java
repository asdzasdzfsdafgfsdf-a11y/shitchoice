package com.choicemod.client;

import com.choicemod.ChoiceMod;
import com.choicemod.client.screen.ChoiceScreen;
import com.choicemod.common.packet.ChoicePackets;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;

public class ChoiceModClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        ChoiceMod.LOGGER.info("[ChoiceMod] Клиентская часть загружена.");

        // Регистрируем payload для приёма
        ClientPlayNetworking.registerGlobalReceiver(
                ChoicePackets.ShowChoicePayload.ID,
                (payload, context) -> {
                    // Открываем экран на главном потоке
                    MinecraftClient client = context.client();
                    client.execute(() -> {
                        client.setScreen(new ChoiceScreen(
                                payload.leftTitle(),  payload.leftBonus(),  payload.leftPenalty(),
                                payload.rightTitle(), payload.rightBonus(), payload.rightPenalty(),
                                payload.timerSeconds()
                        ));
                    });
                }
        );
    }
}
