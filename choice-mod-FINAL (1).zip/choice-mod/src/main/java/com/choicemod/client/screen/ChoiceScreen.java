package com.choicemod.client.screen;

import com.choicemod.common.packet.ChoicePackets;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/**
 * Экран выбора пакета.
 *
 * Макет:
 *  ┌──────────────────────────────────────────────┐
 *  │          ⚡ ВРЕМЯ ВЫБОРА ⚡   [таймер]         │
 *  │  ┌────────────────┐    ┌────────────────┐    │
 *  │  │  [ЛЕВЫЙ ПАКЕТ] │    │ [ПРАВЫЙ ПАКЕТ] │    │
 *  │  │  ✦ бонус       │    │  ✦ бонус       │    │
 *  │  │  ✗ штраф       │    │  ✗ штраф       │    │
 *  │  │  [ВЫБРАТЬ]     │    │  [ВЫБРАТЬ]     │    │
 *  │  └────────────────┘    └────────────────┘    │
 *  └──────────────────────────────────────────────┘
 */
public class ChoiceScreen extends Screen {

    // Данные пакетов
    private final String leftTitle,  leftBonus,  leftPenalty;
    private final String rightTitle, rightBonus, rightPenalty;
    private final int totalSeconds;

    // Таймер (в тиках, 20 тиков/сек)
    private int remainingTicks;
    private boolean chosen = false;
    private int chosenIndex = -1;

    // Цвета
    private static final int COLOR_TITLE   = 0xFFFFD700; // золотой
    private static final int COLOR_BONUS   = 0xFF55FF55; // зелёный
    private static final int COLOR_PENALTY = 0xFFFF5555; // красный
    private static final int COLOR_TIMER   = 0xFFFFFFFF;
    private static final int COLOR_TIMER_LOW = 0xFFFF4444;
    private static final int COLOR_BG_PANEL  = 0xCC111111; // полупрозрачный тёмный
    private static final int COLOR_BG_CHOSEN = 0xCC003300;
    private static final int COLOR_BG_SCREEN = 0xAA000000;

    public ChoiceScreen(
            String leftTitle, String leftBonus, String leftPenalty,
            String rightTitle, String rightBonus, String rightPenalty,
            int timerSeconds
    ) {
        super(Text.literal("Выбор"));
        this.leftTitle   = leftTitle;
        this.leftBonus   = leftBonus;
        this.leftPenalty = leftPenalty;
        this.rightTitle  = rightTitle;
        this.rightBonus  = rightBonus;
        this.rightPenalty = rightPenalty;
        this.totalSeconds = timerSeconds;
        this.remainingTicks = timerSeconds * 20;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int panelW = 180;
        int btnY = this.height / 2 + 60;
        int btnH = 20;

        // Кнопка «Выбрать» для левого пакета
        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("§a✔ Выбрать этот"),
                btn -> choose(0)
        ).dimensions(cx - panelW - 10, btnY, panelW, btnH).build());

        // Кнопка «Выбрать» для правого пакета
        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("§a✔ Выбрать этот"),
                btn -> choose(1)
        ).dimensions(cx + 10, btnY, panelW, btnH).build());
    }

    private void choose(int index) {
        if (chosen) return;
        chosen = true;
        chosenIndex = index;

        // Отправляем на сервер
        ClientPlayNetworking.send(new ChoicePackets.PlayerChoicePayload(index));

        // Закрываем экран через 30 тиков (показываем выбор)
        scheduleClose();
    }

    private void scheduleClose() {
        // Небольшая задержка чтобы показать выделение
        new Thread(() -> {
            try { Thread.sleep(800); } catch (InterruptedException ignored) {}
            if (this.client != null) this.client.execute(() -> this.client.setScreen(null));
        }).start();
    }

    @Override
    public void tick() {
        if (!chosen) {
            remainingTicks--;
            if (remainingTicks <= 0) {
                // Время вышло — авто-выбор случайного пакета
                choose((int)(Math.random() * 2));
            }
        }
    }

    @Override
    public boolean shouldPause() {
        return false; // НЕ ставим игру на паузу
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false; // Нельзя закрыть ESC
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        int cx   = this.width  / 2;
        int cy   = this.height / 2;
        int panelW = 180;
        int panelH = 150;
        int panelTop = cy - panelH / 2 - 10;

        // Фон всего экрана
        context.fill(0, 0, this.width, this.height, COLOR_BG_SCREEN);

        // ── Заголовок ─────────────────────────────────────────────────────
        String header = "⚡  ВРЕМЯ ВЫБОРА  ⚡";
        context.drawCenteredTextWithShadow(textRenderer, Text.literal(header),
                cx, panelTop - 30, COLOR_TITLE);

        // ── Таймер ────────────────────────────────────────────────────────
        int secsLeft = (remainingTicks + 19) / 20;
        int timerColor = secsLeft <= 5 ? COLOR_TIMER_LOW : COLOR_TIMER;
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("§lВремени: " + secsLeft + " сек"),
                cx, panelTop - 16, timerColor);

        // ── Левая панель ──────────────────────────────────────────────────
        int leftX = cx - panelW - 14;
        int rightX = cx + 14;

        drawPanel(context, leftX,  panelTop, panelW, panelH,
                leftTitle,  leftBonus,  leftPenalty,
                chosen && chosenIndex == 0);

        // ── Разделитель ───────────────────────────────────────────────────
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("§7VS"), cx, cy, 0xFFAAAAAA);

        // ── Правая панель ─────────────────────────────────────────────────
        drawPanel(context, rightX, panelTop, panelW, panelH,
                rightTitle, rightBonus, rightPenalty,
                chosen && chosenIndex == 1);

        // Рисуем кнопки поверх
        super.render(context, mouseX, mouseY, delta);
    }

    private void drawPanel(DrawContext ctx, int x, int y, int w, int h,
                           String title, String bonus, String penalty,
                           boolean isChosen) {

        // Фон панели
        int bgColor = isChosen ? COLOR_BG_CHOSEN : COLOR_BG_PANEL;
        ctx.fill(x, y, x + w, y + h, bgColor);

        // Рамка панели
        int borderColor = isChosen ? 0xFF00FF00 : 0xFF888888;
        // верх
        ctx.fill(x,       y,       x + w,     y + 1,     borderColor);
        // низ
        ctx.fill(x,       y + h - 1, x + w,   y + h,     borderColor);
        // лево
        ctx.fill(x,       y,       x + 1,     y + h,     borderColor);
        // право
        ctx.fill(x + w - 1, y,     x + w,     y + h,     borderColor);

        int textX = x + 8;
        int lineH = textRenderer.fontHeight + 4;
        int cur   = y + 10;

        // Название
        ctx.drawTextWithShadow(textRenderer, Text.literal(title), textX, cur, COLOR_TITLE);
        cur += lineH + 4;

        // Разделитель
        ctx.fill(x + 4, cur, x + w - 4, cur + 1, 0xFF555555);
        cur += 6;

        // Бонус
        ctx.drawTextWithShadow(textRenderer, Text.literal("§a✦ Бонус:"), textX, cur, COLOR_BONUS);
        cur += lineH;
        // Перенос по словам для длинных строк
        cur = drawWrapped(ctx, bonus, textX, cur, w - 16, COLOR_BONUS, lineH);
        cur += 6;

        // Штраф
        ctx.drawTextWithShadow(textRenderer, Text.literal("§c✗ Штраф:"), textX, cur, COLOR_PENALTY);
        cur += lineH;
        drawWrapped(ctx, penalty, textX, cur, w - 16, COLOR_PENALTY, lineH);

        // Галочка если выбрано
        if (isChosen) {
            String chosen = "§a§l✔ ВЫБРАНО";
            int tw = textRenderer.getWidth(chosen);
            ctx.drawTextWithShadow(textRenderer, Text.literal(chosen),
                    x + w / 2 - tw / 2, y + h - lineH - 6, 0xFF00FF00);
        }
    }

    /** Простой перенос текста по ширине */
    private int drawWrapped(DrawContext ctx, String text, int x, int y, int maxW, int color, int lineH) {
        // Убираем § коды для измерения ширины, рисуем с ними
        String[] words = text.split(" ");
        StringBuilder line = new StringBuilder();
        int curY = y;
        for (String word : words) {
            String test = line.isEmpty() ? word : line + " " + word;
            if (textRenderer.getWidth(net.minecraft.text.Text.literal(test)) > maxW && !line.isEmpty()) {
                ctx.drawTextWithShadow(textRenderer, net.minecraft.text.Text.literal(line.toString()), x, curY, color);
                curY += lineH;
                line = new StringBuilder(word);
            } else {
                if (!line.isEmpty()) line.append(" ");
                line.append(word);
            }
        }
        if (!line.isEmpty()) {
            ctx.drawTextWithShadow(textRenderer, net.minecraft.text.Text.literal(line.toString()), x, curY, color);
            curY += lineH;
        }
        return curY;
    }
}
